# -*-coding:utf-8 -*-

__version__ = "1.0.20"
__package_name__ = "moore"
