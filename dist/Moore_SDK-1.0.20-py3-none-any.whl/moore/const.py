# -*-coding:utf-8 -*-

MOORE_SDK_BASE_URL = "https://app.molardata.com/open-api"
